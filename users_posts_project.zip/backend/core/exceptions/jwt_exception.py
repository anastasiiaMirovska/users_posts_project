class JWTException(Exception):
    pass

